select 
jform_version 
from cgform_head  
where table_name = '${tableName}'