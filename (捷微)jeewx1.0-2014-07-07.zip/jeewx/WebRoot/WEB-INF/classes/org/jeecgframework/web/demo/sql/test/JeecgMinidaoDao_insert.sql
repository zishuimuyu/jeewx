INSERT INTO jeecg_minidao(id, age, birthday, content, dep_id, email, mobile_phone, office_phone, salary, sex, user_name)
VALUES(
	:jeecgMinidao.id, 
	:jeecgMinidao.age, 
	:jeecgMinidao.birthday, 
	:jeecgMinidao.content, 
	:jeecgMinidao.depId, 
	:jeecgMinidao.email, 
	:jeecgMinidao.mobilePhone, 
	:jeecgMinidao.officePhone, 
	:jeecgMinidao.salary, 
	:jeecgMinidao.sex, 
	:jeecgMinidao.userName
)