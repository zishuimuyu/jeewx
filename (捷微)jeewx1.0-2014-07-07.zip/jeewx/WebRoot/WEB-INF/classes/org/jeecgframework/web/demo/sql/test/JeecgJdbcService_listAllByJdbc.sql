SELECT * 	
	FROM t_s_base_user 