DELETE jeecg_minidao 
WHERE id=:jeecgMinidao.id